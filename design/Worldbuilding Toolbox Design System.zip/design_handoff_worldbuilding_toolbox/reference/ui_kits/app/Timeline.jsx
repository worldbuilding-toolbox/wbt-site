/* Timeline.jsx — eras as bands, events on a spine, with an inspector */

const SAMPLE_ERAS = [
  { id: "e1", label: "First Rise", from: 0, to: 32, color: "#8b5e3c" },
  { id: "e2", label: "Salt Wars", from: 32, to: 56, color: "#7a2e2a" },
  { id: "e3", label: "Long Peace", from: 56, to: 88, color: "#4a6042" },
  { id: "e4", label: "Reckoning", from: 88, to: 100, color: "#2c4a6b" },
];

const SAMPLE_EVENTS = [
  { id: "v1", x: 8, year: "142 AS", title: "Erathine founded", desc: "Cael of Vethran lights the salt-fire. The first three houses swear at the table.", kind: "Treaty" },
  { id: "v2", x: 22, year: "298 AS", title: "First flame at the river mouth", desc: "Lighthouse begun. Stones cut from the southern cliffs.", kind: "Landmark" },
  { id: "v3", x: 38, year: "412 AS", title: "Salt Wars open", desc: "Old houses split. Vethran burns for the first time.", kind: "Conflict" },
  { id: "v4", x: 50, year: "489 AS", title: "Treaty of the Locks", desc: "The salt-lock guild brokers peace. Trade resumes within two seasons.", kind: "Treaty" },
  { id: "v5", x: 68, year: "612 AS", title: "Codex of the Three Tongues begun", desc: "Cael's great-granddaughter starts the comparative archive.", kind: "Document" },
  { id: "v6", x: 82, year: "788 AS", title: "Reign of Heru-the-Quiet", desc: "Eighty years of silence. Three minor border skirmishes.", kind: "Reign" },
  { id: "v7", x: 94, year: "956 AS", title: "Vethran rebuilt in stone", desc: "After the second burning. The basalt towers go up.", kind: "Landmark" },
];

function Timeline() {
  const [eras, setEras] = React.useState(SAMPLE_ERAS);
  const [events, setEvents] = React.useState(SAMPLE_EVENTS);
  const [selected, setSelected] = React.useState(SAMPLE_EVENTS[2]);
  const [editingEra, setEditingEra] = React.useState(null);
  const [eraTerm, setEraTerm] = React.useState("Era");
  const hud = isConstellation();

  return (
    <div style={{ display: "flex", height: "calc(100vh - 56px)" }}>
      {/* Main timeline canvas */}
      <div style={{ flex: 1, padding: "24px 32px", overflow: "auto", display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: 28, fontWeight: 500, letterSpacing: "-0.02em", margin: 0, color: "var(--fg)" }}>
            Erathine cycle
          </h2>
          <Tag tone="neutral">142 — 998 AS</Tag>
          <Tag tone="accent" icon="circle-check">Auto-saved</Tag>
          <div style={{ flex: 1 }} />
          <span style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--fg-muted)" }}>{eraTerm}s:</span>
          <select
            value={eraTerm}
            onChange={(e) => setEraTerm(e.target.value)}
            style={{
              fontFamily: "var(--font-ui)",
              fontSize: 12,
              padding: "4px 8px",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius-sm)",
              background: "var(--bg-elevated)",
              color: "var(--fg)",
            }}
          >
            <option>Era</option>
            <option>Age</option>
            <option>Cycle</option>
            <option>Reign</option>
            <option>Saga</option>
          </select>
          <Button variant="secondary" size="sm" icon="plus">{eraTerm}</Button>
          <Button variant="primary" size="sm" icon="plus">Event</Button>
        </div>

        <p style={{ fontFamily: "var(--font-body)", fontSize: 14, color: "var(--fg-secondary)", margin: "0 0 28px", maxWidth: 60 + "ch" }}>
          856 years of the Erathine ascendancy, from the first salt-fire to the second burning of Vethran. Drag {eraTerm.toLowerCase()}s to resize. Drop events on the spine.
        </p>

        {/* Era track */}
        <div style={{ position: "relative", marginBottom: 8 }}>
          <div style={{ position: "relative", height: 38, display: "flex" }}>
            {eras.map((e) => (
              <div
                key={e.id}
                onClick={() => setEditingEra(e.id === editingEra ? null : e.id)}
                style={{
                  width: `${e.to - e.from}%`,
                  background: hud ? "transparent" : e.color + "1a",
                  border: "1px solid " + (hud ? e.color + "60" : e.color + "40"),
                  borderLeftWidth: e.id === editingEra ? 2 : 1,
                  borderLeftColor: e.id === editingEra ? "var(--accent)" : (e.color + "40"),
                  borderRadius: "var(--radius-sm)",
                  marginRight: 2,
                  padding: "8px 10px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: e.color, flexShrink: 0 }} />
                <span style={{
                  fontFamily: hud ? "var(--font-mono)" : "var(--font-ui)",
                  fontSize: 12,
                  color: "var(--fg)",
                  fontWeight: 500,
                  textTransform: hud ? "uppercase" : "none",
                  letterSpacing: hud ? "0.08em" : "0",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}>{e.label}</span>
                <span style={{ marginLeft: "auto", fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--fg-muted)" }}>{e.to - e.from}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Year ticks */}
        <div style={{ position: "relative", display: "flex", justifyContent: "space-between", marginTop: 18, paddingBottom: 4, fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--fg-muted)" }}>
          {["142 AS", "300 AS", "500 AS", "700 AS", "998 AS"].map((y) => <span key={y}>{y}</span>)}
        </div>

        {/* Spine + events */}
        <div style={{ position: "relative", height: 360, marginTop: 4 }}>
          {/* Spine */}
          <div style={{
            position: "absolute", left: 0, right: 0, top: "50%", height: 1,
            background: "var(--fg-secondary)", opacity: 0.4,
          }} />
          {/* Era boundaries on spine */}
          {eras.map((e) => (
            <div key={e.id + "_b"} style={{
              position: "absolute", left: `${e.from}%`, top: "50%", transform: "translate(-50%, -50%)",
              width: 1, height: 10, background: "var(--fg-muted)", opacity: 0.5,
            }} />
          ))}

          {/* Events */}
          {events.map((ev, i) => {
            const above = i % 2 === 0;
            const isSelected = selected?.id === ev.id;
            return (
              <button
                key={ev.id}
                onClick={() => setSelected(ev)}
                style={{
                  position: "absolute",
                  left: `${ev.x}%`,
                  top: "50%",
                  transform: "translate(-50%, -50%)",
                  background: "transparent",
                  border: "none",
                  padding: 0,
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                  width: 140,
                }}
              >
                {above && <EventCard event={ev} selected={isSelected} placement="above" />}
                <span style={{
                  width: isSelected ? 12 : 10,
                  height: isSelected ? 12 : 10,
                  borderRadius: "50%",
                  background: isSelected ? "var(--accent)" : "var(--fg)",
                  border: "2px solid var(--bg)",
                  boxShadow: isSelected ? (hud ? "0 0 16px var(--accent)" : "0 0 0 4px var(--accent-soft)") : "none",
                  flexShrink: 0,
                }} />
                {!above && <EventCard event={ev} selected={isSelected} placement="below" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Event inspector */}
      {selected && <EventInspector event={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function EventCard({ event, selected, placement }) {
  const hud = isConstellation();
  return (
    <div
      style={{
        marginTop: placement === "below" ? 12 : 0,
        marginBottom: placement === "above" ? 12 : 0,
        padding: "8px 10px",
        background: selected ? "var(--bg-elevated)" : "var(--bg)",
        border: "1px solid " + (selected ? "var(--accent)" : "var(--border)"),
        borderRadius: "var(--radius-md)",
        boxShadow: selected && !hud ? "var(--shadow-md)" : "none",
        textAlign: "left",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        gap: 2,
      }}
    >
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 9, color: selected ? "var(--accent)" : "var(--fg-muted)", textTransform: "uppercase", letterSpacing: "0.12em" }}>
        {event.year}
      </div>
      <div style={{ fontFamily: hud ? "var(--font-sans)" : "var(--font-display)", fontSize: 12, color: "var(--fg)", fontWeight: 500, lineHeight: 1.3 }}>
        {event.title}
      </div>
    </div>
  );
}

function EventInspector({ event, onClose }) {
  const hud = isConstellation();
  return (
    <aside
      style={{
        width: 340,
        flexShrink: 0,
        borderLeft: "1px solid var(--border)",
        background: "var(--bg-elevated)",
        display: "flex",
        flexDirection: "column",
        overflow: "auto",
      }}
    >
      <div style={{ padding: "20px 22px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8 }}>
        <Tag tone="accent" icon="circle-check">{event.kind}</Tag>
        <div style={{ flex: 1 }} />
        <IconButton icon="dots-vertical" label="More" />
        <IconButton icon="x" label="Close" onClick={onClose} />
      </div>
      <div style={{ padding: "20px 22px", display: "flex", flexDirection: "column", gap: 16, flex: 1 }}>
        <div>
          <div style={{ fontFamily: hud ? "var(--font-mono)" : "var(--font-ui)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--fg-muted)", marginBottom: 6 }}>
            {event.year}
          </div>
          <h3 style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 500, letterSpacing: "-0.02em", margin: 0, color: "var(--fg)", lineHeight: 1.2 }}>
            {event.title}
          </h3>
        </div>

        <p style={{ fontFamily: "var(--font-body)", fontSize: 15, lineHeight: 1.65, color: "var(--fg-secondary)", margin: 0 }}>
          {event.desc}
        </p>

        <div style={{ padding: "12px 14px", background: "var(--bg-sunken)", border: "1px solid var(--border)", borderRadius: "var(--radius-md)", display: "grid", gridTemplateColumns: "auto 1fr", gap: "6px 14px", fontFamily: "var(--font-ui)", fontSize: 13 }}>
          <span style={{ color: "var(--fg-muted)" }}>Date</span><span style={{ color: "var(--fg)" }}>{event.year}</span>
          <span style={{ color: "var(--fg-muted)" }}>Era</span><span style={{ color: "var(--fg)" }}>Salt Wars</span>
          <span style={{ color: "var(--fg-muted)" }}>Place</span><span style={{ color: "var(--fg)" }}>Vethran</span>
        </div>

        <div>
          <Field label="Linked articles">
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {["Cael of Vethran", "House of Salt", "Treaty of the Locks"].map((a) => (
                <button
                  key={a}
                  style={{
                    display: "flex", alignItems: "center", gap: 8,
                    padding: "6px 10px",
                    background: "transparent",
                    border: "1px solid var(--border)",
                    borderRadius: "var(--radius-sm)",
                    cursor: "pointer",
                    fontFamily: "var(--font-ui)",
                    fontSize: 13,
                    color: "var(--fg)",
                    textAlign: "left",
                  }}
                >
                  <Icon name="link" size={13} style={{ color: "var(--fg-muted)" }} />
                  {a}
                </button>
              ))}
              <button
                style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "6px 10px",
                  background: "transparent",
                  border: "1px dashed var(--border-strong)",
                  borderRadius: "var(--radius-sm)",
                  cursor: "pointer",
                  fontFamily: "var(--font-ui)",
                  fontSize: 12,
                  color: "var(--fg-muted)",
                  textAlign: "left",
                }}
              >
                <Icon name="plus" size={12} />
                Link an article
              </button>
            </div>
          </Field>
        </div>
      </div>

      <div style={{ padding: 16, borderTop: "1px solid var(--border)", display: "flex", gap: 8 }}>
        <Button variant="secondary" icon="pencil" style={{ flex: 1, justifyContent: "center" }}>Edit</Button>
        <Button variant="ghost" icon="trash" style={{ color: "var(--danger)" }} />
      </div>
    </aside>
  );
}

if (typeof window !== "undefined") { window.Timeline = Timeline; }
