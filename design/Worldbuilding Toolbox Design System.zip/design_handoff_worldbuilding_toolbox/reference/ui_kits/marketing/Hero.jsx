/* Hero.jsx — wordmark + tagline + CTAs + constellation backdrop */

function Hero() {
  return (
    <section
      style={{
        position: "relative",
        padding: "120px 32px 80px",
        overflow: "hidden",
      }}
    >
      {/* Constellation backdrop */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: 0,
          color: "var(--fg)",
          opacity: 0.7,
          pointerEvents: "none",
        }}
      >
        <ConstellationBackdrop highlight={true} />
      </div>
      {/* Bottom protection gradient */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          left: 0, right: 0, bottom: 0, height: 180,
          background: "linear-gradient(to bottom, transparent, var(--bg) 90%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          maxWidth: 900,
          margin: "0 auto",
          textAlign: "center",
          position: "relative",
          zIndex: 1,
        }}
      >
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            fontFamily: "var(--font-ui)",
            fontSize: 12,
            textTransform: "uppercase",
            letterSpacing: "0.16em",
            color: "var(--fg-muted)",
            padding: "6px 14px",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-pill)",
            background: "var(--bg-elevated)",
          }}
        >
          <Icon name="star" size={12} />
          <span>For fiction writers</span>
        </div>
        <h1
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "clamp(44px, 6.4vw, 84px)",
            lineHeight: 1.1,
            letterSpacing: "-0.03em",
            fontWeight: 500,
            color: "var(--fg)",
            margin: "28px 0 0",
          }}
        >
          A quiet place to{" "}
          <span style={{ position: "relative", whiteSpace: "nowrap" }}>
            build worlds
            <svg
              aria-hidden="true"
              width="100%"
              height="14"
              viewBox="0 0 280 14"
              preserveAspectRatio="none"
              style={{
                position: "absolute",
                left: 0, right: 0, bottom: "-0.08em",
                color: "var(--accent)",
                pointerEvents: "none",
              }}
            >
              <path
                d="M 4 8 Q 70 2, 140 7 T 276 6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                style={{
                  strokeDasharray: 300,
                  strokeDashoffset: 300,
                  animation: "draw 1.4s 0.4s cubic-bezier(0.2, 0, 0, 1) forwards",
                }}
              />
            </svg>
          </span>.
        </h1>
        <p
          style={{
            fontFamily: "var(--font-body)",
            fontSize: 20,
            lineHeight: 1.55,
            color: "var(--fg-secondary)",
            maxWidth: 580,
            margin: "28px auto 0",
          }}
        >
          A workspace for novelists who want their timelines, eras, ideas, and lore in one calm, organized place — and not a single notification.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 36 }}>
          <Button variant="primary" size="lg" icon="plus">Start your first world</Button>
          <Button variant="secondary" size="lg">See a sample world</Button>
        </div>
        <div
          style={{
            marginTop: 22,
            fontFamily: "var(--font-ui)",
            fontSize: 13,
            color: "var(--fg-muted)",
          }}
        >
          Free for the first three worlds. No credit card.
        </div>
      </div>

      <style>{`
        @keyframes draw { to { stroke-dashoffset: 0; } }
      `}</style>
    </section>
  );
}

function ConstellationBackdrop({ highlight = false }) {
  // Spread of dots + lines, positioned absolutely. SVG layer for sparse star map.
  return (
    <svg viewBox="0 0 1400 700" preserveAspectRatio="xMidYMid slice" style={{ width: "100%", height: "100%" }} fill="none">
      <g stroke="currentColor" strokeWidth="0.6" strokeOpacity={highlight ? 0.22 : 0.18}>
        <line x1="120" y1="100" x2="220" y2="180" />
        <line x1="220" y1="180" x2="340" y2="120" />
        <line x1="340" y1="120" x2="430" y2="220" />
        <line x1="900" y1="80" x2="1010" y2="150" />
        <line x1="1010" y1="150" x2="1130" y2="100" />
        <line x1="1130" y1="100" x2="1240" y2="200" />
        <line x1="100" y1="480" x2="220" y2="530" />
        <line x1="220" y1="530" x2="320" y2="460" />
        <line x1="780" y1="500" x2="900" y2="580" />
        <line x1="900" y1="580" x2="1040" y2="520" />
      </g>
      <g fill="currentColor">
        {[
          [120,100,2],[220,180,1.4],[340,120,1.8],[430,220,1.5],
          [900,80,1.6],[1010,150,2.2,highlight],[1130,100,1.4],[1240,200,1.8],
          [100,480,1.6],[220,530,1.8],[320,460,1.4],
          [780,500,1.6],[900,580,2,highlight],[1040,520,1.4],
          // scatter
          [80,260,0.8,false,0.5],[300,40,0.8,false,0.5],[520,60,0.8,false,0.5],
          [600,300,0.8,false,0.5],[700,200,0.8,false,0.5],[820,260,0.8,false,0.5],
          [1300,400,0.8,false,0.5],[60,600,0.8,false,0.5],[400,640,0.8,false,0.5],
          [620,580,0.8,false,0.5],[1180,640,0.8,false,0.5],
        ].map(([x,y,r,hi,op], i) => (
          <circle key={i} cx={x} cy={y} r={r} fill={hi ? "#7fdbff" : "currentColor"} opacity={op ?? 1} />
        ))}
      </g>
    </svg>
  );
}

if (typeof window !== "undefined") { window.Hero = Hero; window.ConstellationBackdrop = ConstellationBackdrop; }
