# Marketing UI Kit

The Worldbuilding Toolbox landing page. Single scrollable page demonstrating brand voice, both themes, and the product's core value props.

## Components

| File | What it is |
|---|---|
| `index.html` | Entry point. Loads CSS, mounts the app. Includes the theme toggle in the nav. |
| `Nav.jsx` | Sticky top navigation with theme toggle. |
| `Hero.jsx` | Wordmark + tagline + primary CTA + constellation backdrop. |
| `Features.jsx` | Three-up feature grid with Tabler icons. |
| `ThemePreview.jsx` | Side-by-side window showing the same screen in both themes. |
| `ProductTour.jsx` | Stacked "what you can build" tour panels. |
| `Footer.jsx` | Three-column footer with the wordmark and faint constellation. |
| `Primitives.jsx` | Local Button, Section wrapper. |

## Conventions used

- Pure HTML/CSS layout — no marketing-page-builder smell. Everything respects the type and color tokens.
- One signature moment: the hero's tagline has a thin underline that animates in on load. That's it.
- Theme toggle persists to `localStorage("wbt:theme")`.
- Both themes are valid for the landing page. Default is Manuscript.
