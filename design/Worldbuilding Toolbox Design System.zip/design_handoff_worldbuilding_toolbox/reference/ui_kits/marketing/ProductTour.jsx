/* ProductTour.jsx — stacked "what you can build" preview panels */

function ProductTour() {
  return (
    <section id="tour" style={{ padding: "96px 32px" }}>
      <div style={{ maxWidth: "var(--container)", margin: "0 auto" }}>
        <div style={{ maxWidth: 640, marginBottom: 64 }}>
          <Kicker>The product</Kicker>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(32px, 4vw, 48px)",
              lineHeight: 1.1,
              letterSpacing: "-0.02em",
              fontWeight: 500,
              margin: 0,
              color: "var(--fg)",
            }}
          >
            Three things you'll live in.
          </h2>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <TourRow
            kicker="Timeline"
            title="Eras that you name."
            body="Drag to stretch an era. Click the label to rename. Drop events onto the spine. The product never assumes Gregorian dates — name your own calendar."
          >
            <TimelineSketch />
          </TourRow>

          <TourRow
            reverse
            kicker="Article editor"
            title="Title, picture, description. The rest waits."
            body="When you have a stray idea, capture it with three fields. When it grows into something, add an info-box, subtitles, links to other articles, and any files you have lying around."
          >
            <EditorSketch />
          </TourRow>

          <TourRow
            kicker="Idea inbox"
            title="Catch ideas before they evaporate."
            body="One button, always reachable. Save the spark — main picture, title, two lines. Slot it into a section when you're ready. Or never."
          >
            <InboxSketch />
          </TourRow>
        </div>
      </div>
    </section>
  );
}

function TourRow({ kicker, title, body, reverse, children }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "1fr 1.2fr",
        gap: 48,
        alignItems: "center",
        padding: "32px 0",
        borderTop: "1px solid var(--border)",
      }}
    >
      <div style={{ order: reverse ? 2 : 1 }}>
        <Kicker>{kicker}</Kicker>
        <h3
          style={{
            fontFamily: "var(--font-display)",
            fontSize: 32,
            lineHeight: 1.15,
            letterSpacing: "-0.02em",
            fontWeight: 500,
            margin: 0,
            color: "var(--fg)",
          }}
        >
          {title}
        </h3>
        <p
          style={{
            fontFamily: "var(--font-body)",
            fontSize: 17,
            lineHeight: 1.6,
            color: "var(--fg-secondary)",
            marginTop: 18,
            maxWidth: 48 + "ch",
          }}
        >
          {body}
        </p>
      </div>
      <div style={{ order: reverse ? 1 : 2 }}>{children}</div>
    </div>
  );
}

/* Inline sketches — simplified previews of each surface */

function TimelineSketch() {
  return (
    <div
      style={{
        background: "var(--bg-elevated)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius-lg)",
        padding: 24,
        boxShadow: "var(--shadow-sm)",
      }}
    >
      <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--fg-muted)", marginBottom: 14 }}>Erathine cycle · 856 years</div>
      <div style={{ position: "relative", height: 120 }}>
        {/* Spine */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 70, height: 2, background: "var(--fg-muted)", opacity: 0.4 }} />
        {/* Eras */}
        {[
          { label: "First Rise", start: 0, end: 32, color: "var(--accent)" },
          { label: "Salt Wars", start: 36, end: 56, color: "var(--fg-secondary)" },
          { label: "Long Peace", start: 60, end: 88, color: "var(--success)" },
        ].map((era, i) => (
          <div key={i} style={{ position: "absolute", left: `${era.start}%`, width: `${era.end - era.start}%`, top: 50, height: 22, background: era.color, opacity: 0.16, borderRadius: 4 }}>
            <div style={{ position: "absolute", left: 6, top: -22, fontFamily: "var(--font-ui)", fontSize: 11, color: "var(--fg)", whiteSpace: "nowrap" }}>{era.label}</div>
          </div>
        ))}
        {/* Events */}
        {[
          { x: 8, y: 28, label: "Treaty of Salt" },
          { x: 24, y: 95, label: "First flame" },
          { x: 45, y: 28, label: "Vethran rebuilt" },
          { x: 64, y: 95, label: "Codex begun" },
          { x: 80, y: 28, label: "Last reign" },
        ].map((e, i) => (
          <div key={i} style={{ position: "absolute", left: `${e.x}%`, top: e.y, transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--accent)" }} />
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, color: "var(--fg-secondary)", whiteSpace: "nowrap" }}>{e.label}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 14, fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--fg-muted)" }}>
        <span>142 AS</span><span style={{ marginLeft: "auto" }}>998 AS</span>
      </div>
    </div>
  );
}

function EditorSketch() {
  return (
    <div style={{ background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 24, boxShadow: "var(--shadow-sm)" }}>
      <div style={{ display: "flex", gap: 14 }}>
        <div style={{ width: 88, height: 88, background: "var(--bg-sunken)", border: "1px solid var(--border)", borderRadius: "var(--radius-md)", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--fg-muted)" }}>
          <Icon name="photo" size={22} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--fg-muted)", marginBottom: 6 }}>Character</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 500, color: "var(--fg)", letterSpacing: "-0.01em" }}>Cael of Vethran</div>
          <div style={{ fontFamily: "var(--font-body)", fontSize: 13, color: "var(--fg-secondary)", marginTop: 6, lineHeight: 1.5 }}>The last archivist of the Salt Court. Kept ledgers in three scripts.</div>
        </div>
      </div>
      <div style={{ marginTop: 20, padding: "12px 14px", background: "var(--bg-sunken)", border: "1px solid var(--border)", borderRadius: "var(--radius-md)" }}>
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "8px 16px", fontFamily: "var(--font-ui)", fontSize: 13, color: "var(--fg)" }}>
          <span style={{ color: "var(--fg-muted)" }}>Born</span><span>312 AS</span>
          <span style={{ color: "var(--fg-muted)" }}>House</span><span>Vethran</span>
          <span style={{ color: "var(--fg-muted)" }}>Tongue</span><span>Old Salt · Coastal</span>
        </div>
      </div>
      <div style={{ marginTop: 12, display: "flex", gap: 6, flexWrap: "wrap" }}>
        {["archivist", "House Vethran", "ledger-keeper"].map(t => (
          <span key={t} style={{ fontFamily: "var(--font-ui)", fontSize: 11, padding: "3px 9px", borderRadius: "var(--radius-pill)", background: "var(--bg-sunken)", border: "1px solid var(--border)", color: "var(--fg-secondary)" }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

function InboxSketch() {
  const ideas = [
    { title: "A city built on salt locks", note: "Tidal — the city floods twice an age." },
    { title: "Names that pass between siblings", note: "Surname inherited diagonally, not down." },
    { title: "A god of unfinished maps", note: "Worshipped by cartographers and liars." },
  ];
  return (
    <div style={{ background: "var(--bg-elevated)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 20, boxShadow: "var(--shadow-sm)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--fg-muted)" }}>Inbox · 3 unfiled</div>
        <Button variant="primary" size="sm" icon="plus">Capture</Button>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {ideas.map(i => (
          <div key={i.title} style={{ display: "flex", gap: 12, padding: "10px 12px", border: "1px solid var(--border)", borderRadius: "var(--radius-md)", background: "var(--bg)" }}>
            <div style={{ width: 36, height: 36, background: "var(--bg-sunken)", borderRadius: "var(--radius-sm)", flexShrink: 0, color: "var(--fg-muted)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name="photo" size={14} />
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontFamily: "var(--font-display)", fontSize: 14, fontWeight: 500, color: "var(--fg)" }}>{i.title}</div>
              <div style={{ fontFamily: "var(--font-body)", fontSize: 12, color: "var(--fg-secondary)", marginTop: 2 }}>{i.note}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

if (typeof window !== "undefined") { window.ProductTour = ProductTour; }
