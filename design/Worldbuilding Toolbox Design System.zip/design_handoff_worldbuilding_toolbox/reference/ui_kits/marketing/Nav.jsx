/* Nav.jsx — sticky top navigation */

function Nav() {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      style={{
        position: "sticky",
        top: 0,
        zIndex: 50,
        background: scrolled ? "rgba(11, 14, 20, 0.85)" : "transparent",
        backdropFilter: scrolled ? "blur(10px) saturate(140%)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(10px) saturate(140%)" : "none",
        borderBottom: scrolled ? "1px solid var(--border)" : "1px solid transparent",
        transition: "background var(--duration-med), border-color var(--duration-med)",
      }}
    >
      <div
        style={{
          maxWidth: "var(--container-wide)",
          margin: "0 auto",
          padding: "16px 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 32,
        }}
      >
        <Logo size="md" />
        <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
          <a href="#features" style={navLinkStyle}>Features</a>
          <a href="#tour" style={navLinkStyle}>Tour</a>
          <a href="#help" style={navLinkStyle}>Help</a>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Button variant="ghost" size="sm">Sign in</Button>
          <Button variant="primary" size="sm">Start a world</Button>
        </div>
      </div>
    </nav>
  );
}

const navLinkStyle = {
  color: "var(--fg-secondary)",
  textDecoration: "none",
  fontFamily: "var(--font-mono)",
  fontSize: 12,
  textTransform: "uppercase",
  letterSpacing: "0.12em",
};

if (typeof window !== "undefined") { window.Nav = Nav; }
