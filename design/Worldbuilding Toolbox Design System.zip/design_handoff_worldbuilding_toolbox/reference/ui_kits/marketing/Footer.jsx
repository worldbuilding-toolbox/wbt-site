/* Footer.jsx */

function Footer() {
  return (
    <footer style={{ borderTop: "1px solid var(--border)", padding: "48px 32px 32px", background: "var(--bg-sunken)" }}>
      <div style={{ maxWidth: "var(--container-wide)", margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 48, marginBottom: 48 }}>
          <div>
            <Logo size="md" />
            <p style={{ fontFamily: "var(--font-body)", fontSize: 14, lineHeight: 1.6, color: "var(--fg-secondary)", marginTop: 14, maxWidth: 36 + "ch" }}>
              A quiet place to build worlds. Made for novelists who'd rather think than be sold to.
            </p>
          </div>
          {[
            { title: "Product", links: ["Timeline", "Article editor", "Idea inbox", "Help library"] },
            { title: "Account", links: ["Sign in", "Create", "Pricing", "Export your worlds"] },
            { title: "Quiet", links: ["What we don't do", "Privacy", "Changelog", "Contact"] },
          ].map((col) => (
            <div key={col.title}>
              <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--fg-muted)", fontWeight: 500, marginBottom: 14 }}>{col.title}</div>
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10 }}>
                {col.links.map((l) => (
                  <li key={l}><a href="#" style={{ fontFamily: "var(--font-ui)", fontSize: 14, color: "var(--fg)", textDecoration: "none" }}>{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid var(--border)", paddingTop: 24, fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--fg-muted)" }}>
          <span>© Worldbuilding Toolbox</span>
          <span>v0.1 · alpha</span>
        </div>
      </div>
    </footer>
  );
}

if (typeof window !== "undefined") { window.Footer = Footer; }
