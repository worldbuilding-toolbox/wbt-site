/* Primitives.jsx — shared bits for the marketing kit */

function Button({ variant = "primary", size = "md", children, icon, ...rest }) {
  const base = {
    fontFamily: "var(--font-mono)",
    fontWeight: 500,
    border: "1px solid transparent",
    cursor: "pointer",
    lineHeight: 1,
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    borderRadius: "var(--radius-md)",
    transition: "background var(--duration-fast) var(--ease-out), color var(--duration-fast) var(--ease-out), border-color var(--duration-fast) var(--ease-out)",
    whiteSpace: "nowrap",
    textTransform: "uppercase",
    letterSpacing: "0.08em",
  };
  const sizes = {
    sm: { fontSize: 11, padding: "8px 12px" },
    md: { fontSize: 12, padding: "11px 18px" },
    lg: { fontSize: 13, padding: "14px 22px" },
  };
  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--fg-on-accent)",
      borderColor: "var(--accent)",
    },
    secondary: {
      background: "transparent",
      color: "var(--fg)",
      borderColor: "var(--border-strong)",
    },
    ghost: {
      background: "transparent",
      color: "var(--fg)",
    },
    link: {
      background: "transparent",
      color: "var(--link)",
      padding: "0",
      borderColor: "transparent",
    },
  };

  return (
    <button
      style={{ ...base, ...sizes[size], ...variants[variant] }}
      {...rest}
    >
      {icon && <Icon name={icon} size={size === "lg" ? 16 : 14} />}
      {children}
    </button>
  );
}

function Section({ children, narrow, wide, py = 96, style = {}, ...rest }) {
  const width = wide ? "var(--container-wide)" : narrow ? "var(--container-narrow)" : "var(--container)";
  return (
    <section
      style={{
        padding: `${py}px 32px`,
        ...style,
      }}
      {...rest}
    >
      <div style={{ maxWidth: width, margin: "0 auto" }}>{children}</div>
    </section>
  );
}

function Kicker({ children, style = {} }) {
  return (
    <div
      style={{
        fontFamily: "var(--font-ui)",
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: "0.16em",
        color: "var(--fg-muted)",
        fontWeight: 500,
        marginBottom: 16,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

if (typeof window !== "undefined") {
  Object.assign(window, { Button, Section, Kicker });
}
