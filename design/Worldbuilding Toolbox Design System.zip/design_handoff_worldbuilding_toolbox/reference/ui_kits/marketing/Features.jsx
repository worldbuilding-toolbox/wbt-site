/* Features.jsx — three-up feature grid */

function Features() {
  const features = [
    {
      icon: "timeline",
      title: "Timelines that bend.",
      body: "Eras, ages, cycles, reigns — name them yourself. Mix BCE/AD with custom calendars. Drag events between eras without breaking anything.",
    },
    {
      icon: "book-2",
      title: "Articles, ideas, lore.",
      body: "A simple editor for every entity in your world. Title, picture, description, links to other articles. Expand it when an idea grows up.",
    },
    {
      icon: "paperclip",
      title: "Bring your own files.",
      body: "Drop in Word docs, slides, Krita files, sketches. They live alongside the articles that reference them. Re-label what each link says.",
    },
    {
      icon: "compass",
      title: "Help that adapts.",
      body: "Templates for planets, creatures, factions — modifiable to fit how your world works. Reference videos and pictures live inline.",
    },
    {
      icon: "bookmark",
      title: "Idea inbox.",
      body: "One button to capture a stray idea. Slot it into a section later — or never. Ideas keep their main picture, title, and description.",
    },
    {
      icon: "globe",
      title: "Yours, not ours.",
      body: "Export everything as plain Markdown and your original uploads. Nothing held hostage. Nothing trained on your worlds.",
    },
  ];
  return (
    <section id="features" style={{ padding: "96px 32px", borderTop: "1px solid var(--border)" }}>
      <div style={{ maxWidth: "var(--container-wide)", margin: "0 auto" }}>
        <div style={{ maxWidth: 640, marginBottom: 64 }}>
          <Kicker>What's inside</Kicker>
          <h2
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(32px, 4vw, 48px)",
              lineHeight: 1.1,
              letterSpacing: "-0.02em",
              fontWeight: 500,
              margin: 0,
              color: "var(--fg)",
            }}
          >
            Tools for thinking, not posting.
          </h2>
          <p
            style={{
              fontFamily: "var(--font-body)",
              fontSize: 18,
              lineHeight: 1.6,
              color: "var(--fg-secondary)",
              marginTop: 16,
              maxWidth: 56,
            }}
          />
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 1,
            background: "var(--border)",
            border: "1px solid var(--border)",
          }}
        >
          {features.map((f) => (
            <div
              key={f.title}
              style={{
                background: "var(--bg)",
                padding: "32px 28px",
                display: "flex",
                flexDirection: "column",
                gap: 14,
                minHeight: 220,
              }}
            >
              <div style={{ color: "var(--accent)" }}>
                <Icon name={f.icon} size={24} />
              </div>
              <h3
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: 22,
                  fontWeight: 500,
                  letterSpacing: "-0.01em",
                  margin: 0,
                  color: "var(--fg)",
                  lineHeight: 1.2,
                }}
              >
                {f.title}
              </h3>
              <p
                style={{
                  fontFamily: "var(--font-body)",
                  fontSize: 15,
                  lineHeight: 1.6,
                  color: "var(--fg-secondary)",
                  margin: 0,
                }}
              >
                {f.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

if (typeof window !== "undefined") { window.Features = Features; }
