/* CodeForm.jsx — one-time code path (shown after entering email) */

function CodeForm({ onBack }) {
  const [code, setCode] = React.useState(["", "", "", "", "", ""]);
  const refs = React.useRef([]);

  const onDigit = (i, v) => {
    if (!/^[0-9]?$/.test(v)) return;
    const next = [...code];
    next[i] = v;
    setCode(next);
    if (v && i < 5) refs.current[i + 1]?.focus();
  };

  return (
    <form style={{ display: "flex", flexDirection: "column", gap: 22 }} onSubmit={(e) => e.preventDefault()}>
      <div style={{
        padding: "12px 14px",
        background: "var(--bg-elevated)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius-md)",
        fontFamily: "var(--font-mono)",
        fontSize: 11,
        color: "var(--fg-secondary)",
        textTransform: "uppercase",
        letterSpacing: "0.1em",
      }}>
        Sent to <span style={{ color: "var(--accent)" }}>you@example.com</span>
      </div>

      <Field label="Six-digit code">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8 }}>
          {code.map((d, i) => (
            <input
              key={i}
              ref={(el) => (refs.current[i] = el)}
              value={d}
              onChange={(e) => onDigit(i, e.target.value)}
              maxLength={1}
              inputMode="numeric"
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 24,
                padding: "10px 0",
                textAlign: "center",
                borderRadius: "var(--radius-md)",
                border: "1px solid var(--border-strong)",
                background: "var(--bg-elevated)",
                color: "var(--fg)",
                outline: "none",
                width: "100%",
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "var(--accent)";
                e.target.style.boxShadow = "0 0 0 1px var(--accent) inset, 0 0 16px var(--cyan-glow)";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "var(--border-strong)";
                e.target.style.boxShadow = "none";
              }}
            />
          ))}
        </div>
      </Field>

      <Button variant="primary" size="lg" iconRight="arrow-right" type="submit">
        Verify and sign in
      </Button>

      <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-muted)", textTransform: "uppercase", letterSpacing: "0.12em", textAlign: "center" }}>
        Didn't get it? <a href="#" style={{ color: "var(--accent)" }}>Resend</a> · expires in 9:48
      </div>

      <button
        type="button"
        onClick={onBack}
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: 11,
          textTransform: "uppercase",
          letterSpacing: "0.12em",
          color: "var(--fg-secondary)",
          background: "transparent",
          border: "none",
          cursor: "pointer",
          textAlign: "center",
        }}
      >
        ← Back to password
      </button>
    </form>
  );
}

if (typeof window !== "undefined") { window.CodeForm = CodeForm; }
