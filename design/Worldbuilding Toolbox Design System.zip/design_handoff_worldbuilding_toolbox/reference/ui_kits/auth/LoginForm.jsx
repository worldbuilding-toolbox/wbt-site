/* LoginForm.jsx */

function LoginForm({ onSwitchToSignup, onSwitchToCode }) {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");

  return (
    <form style={{ display: "flex", flexDirection: "column", gap: 18 }} onSubmit={(e) => e.preventDefault()}>
      <Field label="Email">
        <Input
          autoFocus
          type="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </Field>
      <Field
        label="Password"
        hint={<a href="#" style={{ color: "var(--accent)", textDecoration: "none" }}>Forgot</a>}
      >
        <Input
          type="password"
          placeholder="••••••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </Field>

      <Button variant="primary" size="lg" iconRight="arrow-right" type="submit">
        Sign in
      </Button>

      <Divider />

      <OAuthRow />

      <button
        type="button"
        onClick={onSwitchToCode}
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: 11,
          textTransform: "uppercase",
          letterSpacing: "0.12em",
          color: "var(--fg-secondary)",
          background: "transparent",
          border: "none",
          cursor: "pointer",
          textAlign: "center",
          padding: 0,
        }}
      >
        Or send me a one-time code →
      </button>

      <div
        style={{
          fontFamily: "var(--font-sans)",
          fontSize: 13,
          color: "var(--fg-muted)",
          textAlign: "center",
          marginTop: 14,
        }}
      >
        Don't have an account?{" "}
        <button
          type="button"
          onClick={onSwitchToSignup}
          style={{ background: "transparent", border: "none", color: "var(--accent)", cursor: "pointer", fontFamily: "inherit", fontSize: "inherit", padding: 0 }}
        >
          Create one →
        </button>
      </div>
    </form>
  );
}

function Divider() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "8px 0" }}>
      <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
      <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--fg-muted)", textTransform: "uppercase", letterSpacing: "0.16em" }}>OR</span>
      <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
    </div>
  );
}

function OAuthRow() {
  const providers = [
    { name: "Google", id: "google" },
    { name: "Apple", id: "apple" },
    { name: "GitHub", id: "github" },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
      {providers.map((p) => (
        <button
          key={p.id}
          type="button"
          style={{
            background: "var(--bg-elevated)",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-md)",
            padding: "10px",
            color: "var(--fg)",
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            textTransform: "uppercase",
            letterSpacing: "0.1em",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          {p.name}
        </button>
      ))}
    </div>
  );
}

if (typeof window !== "undefined") { Object.assign(window, { LoginForm, Divider, OAuthRow }); }
