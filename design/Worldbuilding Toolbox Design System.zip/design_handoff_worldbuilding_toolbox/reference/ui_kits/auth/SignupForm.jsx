/* SignupForm.jsx */

function SignupForm({ onSwitchToLogin }) {
  const [data, setData] = React.useState({ name: "", email: "", password: "" });
  const onChange = (k) => (e) => setData({ ...data, [k]: e.target.value });

  return (
    <form style={{ display: "flex", flexDirection: "column", gap: 18 }} onSubmit={(e) => e.preventDefault()}>
      <Field label="Your name">
        <Input autoFocus placeholder="What should we call you?" value={data.name} onChange={onChange("name")} />
      </Field>
      <Field label="Email">
        <Input type="email" placeholder="you@example.com" value={data.email} onChange={onChange("email")} />
      </Field>
      <Field label="Password" hint="At least 10 characters. Anything you want.">
        <Input type="password" placeholder="••••••••••••" value={data.password} onChange={onChange("password")} />
      </Field>

      <label
        style={{
          display: "flex",
          alignItems: "flex-start",
          gap: 10,
          fontFamily: "var(--font-sans)",
          fontSize: 13,
          color: "var(--fg-secondary)",
          lineHeight: 1.5,
          cursor: "pointer",
          marginTop: 4,
        }}
      >
        <input
          type="checkbox"
          defaultChecked
          style={{
            marginTop: 3,
            accentColor: "var(--accent)",
            width: 14,
            height: 14,
            flexShrink: 0,
          }}
        />
        <span>
          I've read what's quiet — no tracking, no training on your worlds, plain-Markdown export at any time.
        </span>
      </label>

      <Button variant="primary" size="lg" iconRight="arrow-right" type="submit" style={{ marginTop: 6 }}>
        Create account
      </Button>

      <Divider />

      <OAuthRow />

      <div
        style={{
          fontFamily: "var(--font-sans)",
          fontSize: 13,
          color: "var(--fg-muted)",
          textAlign: "center",
          marginTop: 14,
        }}
      >
        Already have an account?{" "}
        <button
          type="button"
          onClick={onSwitchToLogin}
          style={{ background: "transparent", border: "none", color: "var(--accent)", cursor: "pointer", fontFamily: "inherit", fontSize: "inherit", padding: 0 }}
        >
          Sign in →
        </button>
      </div>
    </form>
  );
}

if (typeof window !== "undefined") { window.SignupForm = SignupForm; }
