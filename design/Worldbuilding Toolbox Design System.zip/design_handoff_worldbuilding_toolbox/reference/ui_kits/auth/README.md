# Auth UI Kit

Login + signup screens for Worldbuilding Toolbox.

## Components

| File | What it is |
|---|---|
| `index.html` | Mounts the auth router. Toggle between sign in / create account / one-time code. |
| `AuthFrame.jsx` | Shared two-column layout: form on the left, constellation hero on the right. |
| `LoginForm.jsx` | Email + password, OAuth providers, "send a one-time code" link. |
| `SignupForm.jsx` | Name, email, password, agreement; light onboarding. |
| `OAuthRow.jsx` | "Continue with" providers. Plain buttons. No icons-as-tooltip-only. |

## Notes

- The visual hierarchy mirrors the main app: bone foreground, deep-space bg, cyan accent.
- The right column is the brand surface — large logotype + constellation moving backdrop.
- Forms are full mono labels (uppercase HUD style) above sans inputs.
- One-time-code path is a stub — the design demonstrates the layout, not the implementation.
