/* Primitives.jsx — local copies used by the auth kit */

function Button({ variant = "primary", size = "md", icon, iconRight, children, style = {}, ...rest }) {
  const sizes = {
    sm: { fontSize: 12, padding: "8px 14px" },
    md: { fontSize: 13, padding: "11px 18px" },
    lg: { fontSize: 14, padding: "13px 20px" },
  };
  const variants = {
    primary: { background: "var(--accent)", color: "var(--fg-on-accent)", border: "1px solid var(--accent)" },
    secondary: { background: "transparent", color: "var(--fg)", border: "1px solid var(--border-strong)" },
    ghost: { background: "transparent", color: "var(--fg)", border: "1px solid transparent" },
    link: { background: "transparent", color: "var(--accent)", border: "none", padding: 0 },
  };
  return (
    <button
      style={{
        fontFamily: "var(--font-mono)",
        fontWeight: 500,
        cursor: "pointer",
        lineHeight: 1,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        borderRadius: "var(--radius-md)",
        whiteSpace: "nowrap",
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        ...sizes[size],
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {icon && <Icon name={icon} size={14} />}
      {children}
      {iconRight && <Icon name={iconRight} size={14} />}
    </button>
  );
}

function Field({ label, children, hint, error }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <label
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: 10,
          textTransform: "uppercase",
          letterSpacing: "0.14em",
          color: error ? "var(--danger)" : "var(--accent)",
          fontWeight: 500,
        }}
      >
        {label}
      </label>
      {children}
      {(hint || error) && (
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: error ? "var(--danger)" : "var(--fg-muted)", textTransform: "uppercase", letterSpacing: "0.1em" }}>
          {error || hint}
        </span>
      )}
    </div>
  );
}

function Input({ style = {}, ...rest }) {
  return (
    <input
      style={{
        fontFamily: "var(--font-sans)",
        fontSize: 14,
        padding: "11px 14px",
        borderRadius: "var(--radius-md)",
        border: "1px solid var(--border-strong)",
        background: "var(--bg-elevated)",
        color: "var(--fg)",
        outline: "none",
        transition: "border-color 120ms",
        width: "100%",
        ...style,
      }}
      onFocus={(e) => {
        e.target.style.borderColor = "var(--accent)";
        e.target.style.boxShadow = "0 0 0 1px var(--accent) inset, 0 0 16px var(--cyan-glow)";
      }}
      onBlur={(e) => {
        e.target.style.borderColor = "var(--border-strong)";
        e.target.style.boxShadow = "none";
      }}
      {...rest}
    />
  );
}

if (typeof window !== "undefined") { Object.assign(window, { Button, Field, Input }); }
