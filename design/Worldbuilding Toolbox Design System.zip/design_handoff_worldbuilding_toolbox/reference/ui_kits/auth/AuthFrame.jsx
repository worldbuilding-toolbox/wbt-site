/* AuthFrame.jsx — two-column shell: form (left) + brand panel (right) */

function AuthFrame({ children, kicker, title, subtitle }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "minmax(380px, 1fr) minmax(0, 1.1fr)",
        minHeight: "100vh",
        background: "var(--bg)",
      }}
    >
      {/* Left — form */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          padding: "32px 48px",
          maxWidth: 560,
          margin: "0 auto",
          width: "100%",
        }}
      >
        <a href="#" style={{ textDecoration: "none" }}>
          <Logo size="md" />
        </a>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", paddingTop: 48, paddingBottom: 48 }}>
          {kicker && (
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 11,
                textTransform: "uppercase",
                letterSpacing: "0.16em",
                color: "var(--accent)",
                fontWeight: 500,
                marginBottom: 12,
              }}
            >
              {kicker}
            </div>
          )}
          <h1
            style={{
              fontFamily: "var(--font-display)",
              fontSize: 36,
              fontWeight: 500,
              letterSpacing: "-0.02em",
              lineHeight: 1.1,
              margin: 0,
              color: "var(--fg)",
            }}
          >
            {title}
          </h1>
          {subtitle && (
            <p
              style={{
                fontFamily: "var(--font-body)",
                fontSize: 16,
                color: "var(--fg-secondary)",
                margin: "10px 0 32px",
                lineHeight: 1.5,
                fontWeight: 300,
                maxWidth: 44 + "ch",
              }}
            >
              {subtitle}
            </p>
          )}
          {children}
        </div>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--fg-muted)", textTransform: "uppercase", letterSpacing: "0.1em" }}>
          v0.1 · alpha
        </div>
      </div>

      {/* Right — brand panel */}
      <BrandPanel />
    </div>
  );
}

function BrandPanel() {
  return (
    <div
      style={{
        position: "relative",
        overflow: "hidden",
        background: "linear-gradient(180deg, #11151d 0%, #060810 100%)",
        borderLeft: "1px solid var(--border)",
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-end",
        padding: "48px",
        minHeight: 480,
      }}
    >
      {/* Scan-line texture */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: "var(--grain)",
          pointerEvents: "none",
          zIndex: 3,
        }}
      />
      {/* Moving constellation */}
      <ConstellationLive />
      {/* Bottom protection gradient */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          left: 0, right: 0, bottom: 0, height: "55%",
          background: "linear-gradient(to bottom, transparent, rgba(6, 8, 16, 0.85) 70%, rgba(6, 8, 16, 0.95))",
          pointerEvents: "none",
          zIndex: 2,
        }}
      />
      {/* Quote */}
      <div style={{ position: "relative", zIndex: 4 }}>
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            textTransform: "uppercase",
            letterSpacing: "0.16em",
            color: "var(--accent)",
            marginBottom: 14,
          }}
        >
          From the help library
        </div>
        <blockquote
          style={{
            fontFamily: "var(--font-display)",
            fontSize: 28,
            lineHeight: 1.25,
            letterSpacing: "-0.02em",
            color: "var(--fg)",
            margin: 0,
            maxWidth: 24 + "ch",
            fontWeight: 400,
          }}
        >
          A planet is not an encyclopedia. Build only what you need for the next chapter.
        </blockquote>
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            textTransform: "uppercase",
            letterSpacing: "0.12em",
            color: "var(--fg-muted)",
            marginTop: 18,
          }}
        >
          — How to design a planet
        </div>
      </div>
    </div>
  );
}

function ConstellationLive() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 600 800"
      preserveAspectRatio="xMidYMid slice"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        zIndex: 1,
      }}
      fill="none"
    >
      <defs>
        <style>{`
          .ctn { transform-box: fill-box; transform-origin: center; }
          .ctn.c1 { animation: drift-1 36s ease-in-out infinite; }
          .ctn.c2 { animation: drift-2 48s ease-in-out infinite; }
          .ctn.c3 { animation: drift-3 42s ease-in-out infinite; }
          @keyframes drift-1 { 0%,100% { transform: translate(0,0); } 50% { transform: translate(8px,-6px); } }
          @keyframes drift-2 { 0%,100% { transform: translate(0,0); } 50% { transform: translate(-6px,4px); } }
          @keyframes drift-3 { 0%,100% { transform: translate(0,0); } 50% { transform: translate(5px,5px); } }
          .tw { animation: tw 5s ease-in-out infinite; }
          .tw2 { animation: tw 4.4s ease-in-out infinite 1.6s; }
          .tw3 { animation: tw 6.2s ease-in-out infinite 2.4s; }
          @keyframes tw { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }
          .anc { animation: anc 5.5s ease-in-out infinite; }
          @keyframes anc {
            0%,100% { opacity: 1; filter: drop-shadow(0 0 0px #7fdbff); }
            50%     { opacity: 0.9; filter: drop-shadow(0 0 8px #7fdbff); }
          }
        `}</style>
      </defs>

      <g className="ctn c1">
        <g stroke="#e6e7eb" strokeWidth="0.5" strokeOpacity="0.28">
          <line x1="120" y1="100" x2="240" y2="180" />
          <line x1="240" y1="180" x2="340" y2="120" />
          <line x1="340" y1="120" x2="440" y2="220" />
          <line x1="240" y1="180" x2="260" y2="280" />
        </g>
        <g fill="#e6e7eb">
          <circle className="tw" cx="120" cy="100" r="2" />
          <circle className="anc" cx="240" cy="180" r="3" fill="#7fdbff" />
          <circle className="tw2" cx="340" cy="120" r="2" />
          <circle className="tw3" cx="440" cy="220" r="2" />
          <circle className="tw" cx="260" cy="280" r="1.8" />
        </g>
      </g>

      <g className="ctn c2">
        <g stroke="#e6e7eb" strokeWidth="0.5" strokeOpacity="0.22">
          <line x1="80" y1="420" x2="180" y2="480" />
          <line x1="180" y1="480" x2="280" y2="440" />
          <line x1="280" y1="440" x2="380" y2="520" />
        </g>
        <g fill="#e6e7eb">
          <circle className="tw3" cx="80" cy="420" r="1.6" />
          <circle className="tw" cx="180" cy="480" r="2" />
          <circle className="anc" cx="280" cy="440" r="2.8" fill="#7fdbff" />
          <circle className="tw2" cx="380" cy="520" r="1.8" />
        </g>
      </g>

      <g className="ctn c3">
        <g stroke="#e6e7eb" strokeWidth="0.5" strokeOpacity="0.22">
          <line x1="380" y1="600" x2="480" y2="640" />
          <line x1="480" y1="640" x2="540" y2="720" />
        </g>
        <g fill="#e6e7eb">
          <circle className="tw" cx="380" cy="600" r="1.6" />
          <circle className="tw2" cx="480" cy="640" r="2" />
          <circle className="anc" cx="540" cy="720" r="2.6" fill="#7fdbff" />
        </g>
      </g>

      <g fill="#e6e7eb">
        <circle cx="60" cy="280" r="0.7" opacity="0.5" />
        <circle cx="380" cy="60" r="0.7" opacity="0.5" />
        <circle cx="520" cy="380" r="0.7" opacity="0.5" />
        <circle cx="160" cy="600" r="0.7" opacity="0.5" />
        <circle cx="560" cy="180" r="0.7" opacity="0.5" />
        <circle cx="80" cy="160" r="0.7" opacity="0.5" />
        <circle cx="400" cy="340" r="0.7" opacity="0.5" />
        <circle cx="200" cy="720" r="0.7" opacity="0.5" />
      </g>
    </svg>
  );
}

if (typeof window !== "undefined") { window.AuthFrame = AuthFrame; }
